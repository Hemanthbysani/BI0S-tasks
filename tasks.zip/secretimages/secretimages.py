usr_input = input()
list1 = usr_input
bmp = ".bmp"
png = ".png"
jpeg = ".jpeg"

print(list1.count(png), list1.count(bmp), list1.count(jpeg), sep =" ")
