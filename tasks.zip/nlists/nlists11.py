#l = []
#second_lowest_names = []
#scores = set()

#for _ in range(int(input())):
#    name = input()
#    score = float(input())
#    l.append([name, score])
#    scores.add(score)
        
#second_lowest = sorted(scores)[1]

#for name, score in l:
#    if score == second_lowest:
#        second_lowest_names.append(name)

#for name in sorted(second_lowest_names):
#    print(name, end='\n')

#i found this solution in hackerrank but i could not understand it at all, pls help.
